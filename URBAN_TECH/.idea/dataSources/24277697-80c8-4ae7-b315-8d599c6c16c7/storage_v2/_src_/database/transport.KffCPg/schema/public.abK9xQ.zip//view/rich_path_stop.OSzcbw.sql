create view rich_path_stop(id, stop_id, weight, route_path_id, lat, lon) as
SELECT s1.id,
       s1.stop_id,
       s1.weight,
       s1.route_path_id,
       stop.lat,
       stop.lon
FROM (path_stop s1
         LEFT JOIN stop ON (((s1.stop_id)::text = (stop.id)::text)));

alter table rich_path_stop
    owner to postgres;

