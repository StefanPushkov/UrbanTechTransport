create function st_quantile(rast raster, quantiles double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_quantile($1, 1, TRUE, 1, $2)
$$;

comment on function st_quantile(raster, double precision[], out double precision, out double precision) is 'args: rast, quantiles - Compute quantiles for a raster or raster table coverage in the context of the sample or population. Thus, a value could be examined to be at the rasters 25%, 50%, 75% percentile.';

alter function st_quantile(raster, double precision[], out double precision, out double precision) owner to postgres;

