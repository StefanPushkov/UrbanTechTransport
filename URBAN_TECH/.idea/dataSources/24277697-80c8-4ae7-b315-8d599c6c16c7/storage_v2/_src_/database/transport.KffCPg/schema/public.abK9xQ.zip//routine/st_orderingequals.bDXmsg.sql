create function st_orderingequals(geometrya geometry, geometryb geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.~=) $2 AND public._ST_OrderingEquals($1, $2)

$$;

comment on function st_orderingequals(geometry, geometry) is 'args: A, B - Returns true if the given geometries represent the same geometry and points are in the same directional order.';

alter function st_orderingequals(geometry, geometry) owner to postgres;

