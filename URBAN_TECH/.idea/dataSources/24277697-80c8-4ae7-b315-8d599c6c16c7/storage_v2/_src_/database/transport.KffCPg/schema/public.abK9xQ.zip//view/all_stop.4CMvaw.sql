create view all_stop(id, type, lat, lon, geopoint) as
    SELECT s.id,
           s.type,
           s.lat,
           s.lon,
           s.geopoint
    FROM stop s
    WHERE (s.type <> 'subway_hall'::type_stop)
    UNION
    SELECT h.id,
           'subway_hall'::type_stop AS type,
           h.lat,
           h.lon,
           h.geopoint
    FROM subway_hall h;

alter table all_stop
    owner to postgres;

