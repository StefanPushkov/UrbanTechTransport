create function st_approxcount(rastertable text, rastercolumn text, sample_percent double precision) returns bigint
    stable
    strict
    language sql
as
$$
SELECT public._ST_count($1, $2, 1, TRUE, $3)
$$;

alter function st_approxcount(text, text, double precision) owner to postgres;

