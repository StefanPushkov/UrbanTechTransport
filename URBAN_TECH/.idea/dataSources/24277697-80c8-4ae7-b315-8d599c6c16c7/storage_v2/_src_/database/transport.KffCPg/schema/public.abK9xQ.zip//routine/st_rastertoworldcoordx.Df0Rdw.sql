create function st_rastertoworldcoordx(rast raster, xr integer) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT longitude FROM public._ST_rastertoworldcoord($1, $2, NULL)
$$;

comment on function st_rastertoworldcoordx(raster, integer) is 'args: rast, xcolumn - Returns the geometric X coordinate upper left of a raster, column and row. Numbering of columns and rows starts at 1.';

alter function st_rastertoworldcoordx(raster, integer) owner to postgres;

